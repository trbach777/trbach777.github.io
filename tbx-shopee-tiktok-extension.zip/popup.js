const DEFAULT_URL = 'https://trbach777.github.io/cms-data.json';

async function renderStatus(force = false) {
  const syncInfo = document.getElementById('syncInfo');
  const statusMsg = document.getElementById('statusMsg');
  try {
    const res = await chrome.runtime.sendMessage({ type: force ? 'REFRESH_CATALOG' : 'GET_CATALOG' });
    if (res && res.ok && res.catalog) {
      const prodCount = Array.isArray(res.catalog.products) ? res.catalog.products.length : 0;
      const matCount = Array.isArray(res.catalog.print3dMaterials) ? res.catalog.print3dMaterials.length : 5;
      const tsStr = res.cachedAt ? new Date(res.cachedAt).toLocaleString('vi-VN') : 'Mặc định';
      syncInfo.textContent = `✓ Đã nạp ${prodCount} sản phẩm kho & ${matCount} loại nhựa 3D (Cập nhật: ${tsStr})`;
      if (force) statusMsg.textContent = '✓ Đã đồng bộ bảng giá mới nhất!';
    } else {
      syncInfo.textContent = 'Đang dùng bảng giá dự phòng offline.';
    }
  } catch (err) {
    syncInfo.textContent = 'Lỗi đọc cache: ' + (err?.message || err);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const catalogInput = document.getElementById('catalogUrl');
  const webhookInput = document.getElementById('webhookUrl');
  const statusMsg = document.getElementById('statusMsg');
  const stored = await chrome.storage.local.get(['tbx_catalog_url', 'tbx_webhook_url']);
  catalogInput.value = stored.tbx_catalog_url || DEFAULT_URL;
  webhookInput.value = stored.tbx_webhook_url || '';

  await renderStatus(false);

  document.getElementById('saveBtn').addEventListener('click', async () => {
    await chrome.storage.local.set({
      tbx_catalog_url: catalogInput.value.trim() || DEFAULT_URL,
      tbx_webhook_url: webhookInput.value.trim(),
    });
    statusMsg.textContent = '✓ Đã lưu cấu hình!';
  });

  document.getElementById('refreshBtn').addEventListener('click', async () => {
    statusMsg.textContent = 'Đang tải bảng giá...';
    await chrome.storage.local.set({
      tbx_catalog_url: catalogInput.value.trim() || DEFAULT_URL,
      tbx_webhook_url: webhookInput.value.trim(),
    });
    await renderStatus(true);
  });
});
