(function (root) {
  var DEFAULT_MATERIALS = [
    { id: 'pla', name: 'PLA', pricePerGram: 800, costPricePerGram: 250, baseFee: 0 },
    { id: 'petg', name: 'PETG', pricePerGram: 400, costPricePerGram: 200, baseFee: 0 },
    { id: 'abs', name: 'ABS', pricePerGram: 1300, costPricePerGram: 300, baseFee: 0 },
    { id: 'tpu', name: 'TPU', pricePerGram: 1600, costPricePerGram: 450, baseFee: 0 },
    { id: 'carbon-cf', name: 'Cacbon CF', pricePerGram: 30000, costPricePerGram: 1500, baseFee: 0 }
  ];

  var PRODUCT_ALIAS_KEYWORDS = {
    H743ZIT6: ['h743', 'stm32h743', 'bo trung tam', 'mach trung tam', 'bo dieu khien trung tam', 'stm32 h7'],
    'PIDSM-V2.2': ['pidsm', 'driver dc servo', 'driver servo', 'servo encoder', 'mach pid'],
    'IMU-STMV2': ['imu', 'imustm', 'chong nhay goc', 'cam bien quan tinh', '6 truc'],
    'GAMEPAD-BLE': ['gamepad', 'tay cam', 'tay cam ble', 'tay cam khong day'],
    'INPUT-F4-IO': ['input f4', 'input code', 'cach ly 24v', 'board doc cam bien', 'mach io'],
    'MECANUM-AL152': ['mecanum', 'banh mecanum', 'banh xe mecanum', 'al152'],
    'MOTOR-24V-ENC': ['dong co 24v', 'motor 24v', 'giam toc 24v', '24v encoder', 'motor encoder'],
    'LZR-IND-05V': ['laser', 'cam bien laser', 'lzr', '0-5v'],
    'KIT-AGV-MEC4': ['kit agv', 'xe agv', 'mo hinh agv', 'agv 4 banh'],
    'KIT-SERVO-LAB': ['kit servo', 'thuc hanh servo', 'servo lab'],
    'KIT-SORT-ARM': ['bang tai', 'phan loai san pham', 'sort arm']
  };

  var STOP_TOKENS = {
    bo: 1, mach: 1, dieu: 1, khien: 1, dong: 1, co: 1, cam: 1, bien: 1, mo: 1,
    hinh: 1, do: 1, an: 1, nckh: 1, theo: 1, yeu: 1, cau: 1, full: 1, kit: 1,
    cho: 1, va: 1, cua: 1, gia: 1, bao: 1, nhieu: 1, cai: 1, chiec: 1, '24v': 1, stm32: 1
  };

  function stripVnTones(str) {
    return String(str || '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  }

  function escapeRegExp(str) {
    return String(str || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function formatVnd(amount) {
    var n = Number(amount || 0);
    if (!n || n <= 0) return 'Liên hệ báo giá';
    return n.toLocaleString('vi-VN') + ' ₫';
  }

  function getLocalDateYmd(offsetDays) {
    var now = new Date();
    var d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + (offsetDays || 0));
    return (
      d.getFullYear() +
      '-' +
      String(d.getMonth() + 1).padStart(2, '0') +
      '-' +
      String(d.getDate()).padStart(2, '0')
    );
  }

  function calculateDeliveryUrgency(deadlineYmd) {
    var trimmed = String(deadlineYmd || '').trim();
    var match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
    if (!match) {
      return {
        deadlineYmd: '',
        surchargePercent: 0,
        displayText: 'Tiêu chuẩn 2–7 ngày (Miễn phí)'
      };
    }
    var target = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var daysRemaining = Math.round((target.getTime() - today.getTime()) / 86400000);
    var pct = 0;
    var label = 'Hạn 2–7 ngày (Miễn phí)';
    if (daysRemaining <= 0) {
      pct = 15;
      label = 'In gấp trong ngày (+15%)';
    } else if (daysRemaining === 1) {
      pct = 6;
      label = 'Hạn sau 1 ngày (+6%)';
    } else if (daysRemaining > 7) {
      pct = 0;
      label = 'Tiêu chuẩn >7 ngày (Miễn phí)';
    }
    return {
      deadlineYmd: trimmed,
      surchargePercent: pct,
      displayText: match[3] + '/' + match[2] + '/' + match[1] + ' · ' + label
    };
  }

  function calculatePrint3DPrice(materials, materialName, totalWeightGrams, quantity, rushSurchargePercent) {
    var list = Array.isArray(materials) && materials.length > 0 ? materials : DEFAULT_MATERIALS;
    var target = String(materialName || '').trim().toLowerCase();
    var matched = list[0];
    for (var i = 0; i < list.length; i++) {
      if (String(list[i].name || '').trim().toLowerCase() === target) {
        matched = list[i];
        break;
      }
    }
    var g = Math.max(0, Number(totalWeightGrams) || 0);
    var qty = Math.max(1, Math.round(Number(quantity) || 1));
    var subtotalAmount = g > 0 ? Math.round(g * matched.pricePerGram + (matched.baseFee || 0) * qty) : 0;
    var pct = Math.max(0, Number(rushSurchargePercent) || 0);
    var rushFeeAmount = subtotalAmount > 0 && pct > 0 ? Math.round((subtotalAmount * pct) / 100) : 0;
    return {
      unitPricePerGram: matched.pricePerGram,
      baseFee: matched.baseFee || 0,
      subtotalAmount: subtotalAmount,
      rushSurchargePercent: pct,
      rushFeeAmount: rushFeeAmount,
      totalAmount: subtotalAmount + rushFeeAmount
    };
  }

  function extractCustomerOnlyText(rawText, shopPhoneDigits, shopEmailLower) {
    var lines = String(rawText || '').replace(/\r\n/g, '\n').split('\n');
    var kept = [];
    for (var i = 0; i < lines.length; i++) {
      var trimmed = lines[i].trim();
      if (!trimmed) continue;
      var plain = stripVnTones(trimmed).toLowerCase();
      if (/^(?:shop|ban|admin|teebi|tbx|nguoi ban|seller|cua hang)\s*:/i.test(plain)) continue;
      var lineDigits = trimmed.replace(/[\s.-]/g, '');
      if (shopPhoneDigits && lineDigits.indexOf(shopPhoneDigits) !== -1 && /^(?:shop|lien he|zalo shop|hotline)/i.test(plain)) continue;
      if (shopEmailLower && trimmed.toLowerCase().indexOf(shopEmailLower) !== -1 && /^(?:shop|gmail shop|email shop)/i.test(plain)) continue;
      var cleaned = trimmed.replace(/^(?:\[(?:shopee|tiktok|zalo)\]\s*)?(?:khach(?:\s+hang)?|buyer|kh)\s*:\s*/i, '').trim();
      if (cleaned) kept.push(cleaned);
    }
    return kept.join('\n');
  }

  function detectPlatform(rawText, hint) {
    if (hint && hint !== 'auto') return hint;
    var low = stripVnTones(rawText).toLowerCase();
    if (/\bshopee\b|banhang\.shopee|shopee\.vn|shopee chat|spx/.test(low)) return 'shopee';
    if (/\btiktok\b|tiktokshop|tiktok shop|seller-vn\.tiktok/.test(low)) return 'tiktok';
    if (/\bzalo\b/.test(low)) return 'zalo';
    return 'other';
  }

  function extractValidPhones(text, shopPhoneDigits) {
    var matches = text.match(/(?:\+?84|0)(?:[\s.\-]*\d){8,10}\b/g) || [];
    var valid = [];
    for (var i = 0; i < matches.length; i++) {
      var digits = matches[i].replace(/\D/g, '');
      if (digits.indexOf('84') === 0 && digits.length >= 10) digits = '0' + digits.slice(2);
      if (!/^0[235789]\d{8}$/.test(digits)) continue;
      if (shopPhoneDigits && digits === shopPhoneDigits) continue;
      if (/^0(\d)\1{8}$/.test(digits) || digits === '0123456789' || digits === '0987654321') continue;
      if (valid.indexOf(digits) === -1) valid.push(digits);
    }
    return valid;
  }

  function extractEmail(text, shopEmailLower) {
    var matches = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
    for (var i = 0; i < matches.length; i++) {
      var low = matches[i].toLowerCase();
      if (shopEmailLower && low === shopEmailLower) continue;
      return low;
    }
    return '';
  }

  function extractCustomerName(customerText, rawText, hint) {
    var plainLines = stripVnTones(customerText).split('\n');
    var origLines = customerText.split('\n');
    var re = /(?:^|\n)\s*(?:ho\s*ten|ten\s*khach(?:\s*hang)?|nguoi\s*nhan|ten)\s*[:\-]\s*([^\n,;|]+)/i;
    for (var i = 0; i < plainLines.length; i++) {
      var m = re.exec(plainLines[i]);
      if (m && m[1]) {
        var origLine = origLines[i] || '';
        var colonIdx = origLine.search(/[:\-]/);
        var val = (colonIdx !== -1 ? origLine.slice(colonIdx + 1) : m[1]).split(/[,;|]/)[0].trim();
        if (val.length >= 2 && val.length <= 60 && !/\d{6,}/.test(val)) return val;
      }
    }
    var rawHdr = /^\s*(?:\[(?:shopee|tiktok|zalo)\]\s*)?([^:\n]{2,45}):/i.exec(rawText);
    if (rawHdr && rawHdr[1]) {
      var cand = rawHdr[1].trim();
      var candPlain = stripVnTones(cand).toLowerCase();
      if (!/^(?:shop|ban|admin|teebi|tbx|khach|khach hang|buyer|sdt|so dien thoai|dia chi|dc|email|ma don|link|http)/.test(candPlain) && !/\d{7,}/.test(cand)) {
        return cand;
      }
    }
    var cleanHint = String(hint || '').trim();
    return cleanHint.length >= 2 ? cleanHint : 'Khách chat';
  }

  function extractShippingInfo(customerText, customerPhone) {
    var plainAll = stripVnTones(customerText).toLowerCase();
    if (/(?:nhan|lay|den)\s*(?:truc tiep|tai xuong|o xuong|o shop|tai shop)|qua\s*lay|tu\s*qua/.test(plainAll)) {
      return { shippingMethod: 'pickup', shippingAddress: 'Nhận trực tiếp tại xưởng' };
    }
    var lines = customerText.split('\n');
    for (var i = 0; i < lines.length; i++) {
      var trimmed = lines[i].trim();
      if (!trimmed) continue;
      var plain = stripVnTones(trimmed).toLowerCase();
      var labelMatch = /^(?:dia\s*chi|d\/c|dc|noi\s*nhan|ship(?:\s*ve|\s*toi|\s*den)?|giao(?:\s*hang)?(?:\s*ve|\s*toi|\s*den)?)\s*[:\-]\s*(.+)$/i.exec(plain);
      if (labelMatch) {
        var colonIdx = trimmed.search(/[:\-]/);
        var extracted = (colonIdx !== -1 ? trimmed.slice(colonIdx + 1) : trimmed)
          .replace(customerPhone || '__NONE__', '')
          .replace(/^\s*[-–,;.]+\s*/, '')
          .trim();
        if (extracted.length >= 6) return { shippingMethod: 'delivery', shippingAddress: extracted };
      }
    }
    for (var j = 0; j < lines.length; j++) {
      var lt = lines[j].trim();
      if (!lt || /https?:\/\//i.test(lt)) continue;
      var lp = stripVnTones(lt).toLowerCase();
      var adminUnits = lp.match(/\b(?:so|ngo|ngach|hem|duong|pho|thon|ap|xom|phuong|xa|thi tran|quan|huyen|thanh pho|tp|tinh|ha noi|hcm|ho chi minh|sai gon|da nang|hai phong|can tho|binh duong|dong nai|bac ninh)\b/g) || [];
      if (lt.length >= 14 && (adminUnits.length >= 2 || (adminUnits.length >= 1 && lt.indexOf(',') !== -1))) {
        var cleaned = lt.replace(/(?:sdt|dt|sđt)[:\s]*0\d{9}/gi, '').replace(/[,;\-|\s]+$/, '').trim();
        if (cleaned.length >= 10) return { shippingMethod: 'delivery', shippingAddress: cleaned };
      }
    }
    return { shippingMethod: 'delivery', shippingAddress: '' };
  }

  function extractQuantityNearPattern(plainText, patternStr) {
    var beforeRe = new RegExp('(?:^|[\\s,;(+])(\\d{1,3})\\s*(?:bo|cai|chiec|mach|con|cay|module|cap|don)?\\s*(?:' + patternStr + ')\\b', 'i');
    var bMatch = beforeRe.exec(plainText);
    if (bMatch && bMatch[1]) {
      var bn = parseInt(bMatch[1], 10);
      if (bn >= 1 && bn <= 200) return bn;
    }
    var afterRe = new RegExp('(?:' + patternStr + ')[^\\n.,;]{0,22}?(?:[x×*]|\\bsl\\b[:\\s]*|\\bso\\s*luong\\b[:\\s]*)(\\d{1,3})\\b', 'i');
    var aMatch = afterRe.exec(plainText);
    if (aMatch && aMatch[1]) {
      var an = parseInt(aMatch[1], 10);
      if (an >= 1 && an <= 200) return an;
    }
    return 1;
  }

  function matchProductsFromText(customerText, products) {
    var plain = stripVnTones(customerText).toLowerCase();
    var matched = [];
    var list = Array.isArray(products) ? products : [];
    for (var i = 0; i < list.length; i++) {
      var prod = list[i];
      if (!prod || prod.code === 'IN3D-REQ') continue;
      var codePlain = stripVnTones(prod.code).toLowerCase();
      var aliases = PRODUCT_ALIAS_KEYWORDS[String(prod.code).toUpperCase()] || [];
      var score = 0;
      var bestPat = escapeRegExp(codePlain);
      if (new RegExp('\\b' + escapeRegExp(codePlain) + '\\b', 'i').test(plain)) {
        score = 100;
      } else {
        for (var a = 0; a < aliases.length; a++) {
          if (new RegExp('\\b' + escapeRegExp(aliases[a]) + '\\b', 'i').test(plain)) {
            score = 85;
            bestPat = escapeRegExp(aliases[a]);
            break;
          }
        }
      }
      if (score === 0) {
        var nameVi = (prod.name && prod.name.vi) ? prod.name.vi : (prod.name || '');
        var nameTokens = stripVnTones(nameVi).toLowerCase().split(/[^a-z0-9]+/).filter(function (t) {
          return t.length >= 3 && !STOP_TOKENS[t];
        });
        var hitTokens = nameTokens.filter(function (t) {
          return new RegExp('\\b' + escapeRegExp(t) + '\\b', 'i').test(plain);
        });
        if (hitTokens.length >= 2) {
          score = 60 + hitTokens.length * 5;
          bestPat = escapeRegExp(hitTokens[0]);
        }
      }
      if (score > 0) {
        matched.push({
          productId: prod.id,
          code: prod.code,
          name: (prod.name && prod.name.vi) ? prod.name.vi : prod.name,
          unitPrice: Number(prod.price || 0),
          costPrice: Number(prod.costPrice || 0),
          stock: Number(prod.stock || 0),
          unit: prod.unit || 'Cái',
          quantity: extractQuantityNearPattern(plain, bestPat),
          matchScore: score
        });
      }
    }
    return matched.sort(function (a, b) { return b.matchScore - a.matchScore; });
  }

  function extractPrint3DSpec(customerText, materials) {
    var plain = stripVnTones(customerText).toLowerCase();
    var urlMatches = customerText.match(/https?:\/\/(?:drive|docs)\.google\.com\/[^\s<>"')]+/gi) || [];
    var driveUrls = [];
    for (var u = 0; u < urlMatches.length; u++) {
      var cleanUrl = urlMatches[u].replace(/[.,;!?]+$/, '');
      if (driveUrls.indexOf(cleanUrl) === -1) driveUrls.push(cleanUrl);
    }
    var has3dSignal =
      driveUrls.length > 0 ||
      /\bin\s*3d\b|\bin3d\b|\.stl\b|\.zip\b|\binfill\b|\bgcode\b|\bsupport\b|\bfilament\b|\bnhua\s*(?:pla|petg|abs|tpu|cf)\b|\b(?:pla|petg|abs|tpu)\b|\bcacbon\s*cf\b|\bvo\s*hop(?:\s*in\s*3d)?\b/.test(plain);
    if (!has3dSignal) return null;

    var material = (materials && materials[0] && materials[0].name) || 'PLA';
    if (/\bcacbon\b|\bcarbon\b|\bpetg[\s-]*cf\b|\bpla[\s-]*cf\b|\bcf\b/.test(plain)) material = 'Cacbon CF';
    else if (/\bpetg\b/.test(plain)) material = 'PETG';
    else if (/\btpu\b/.test(plain)) material = 'TPU';
    else if (/\babs\b/.test(plain)) material = 'ABS';
    else if (/\bpla\b/.test(plain)) material = 'PLA';

    var infill = '20%';
    var infillM = /(?:infill\s*[:=]?\s*(\d{1,3})\s*%?|(\d{1,3})\s*%\s*infill)/i.exec(plain);
    if (infillM) {
      infill = Math.min(100, Math.max(10, parseInt(infillM[1] || infillM[2], 10) || 20)) + '%';
    }

    var quantity = 1;
    var qtyM = /(?:so\s*luong|\bsl\b)\s*[:=]?\s*(\d{1,3})|\b(\d{1,3})\s*(?:cai|chiec|chi tiet|vo|hop|bo|part)\b|\bx\s*(\d{1,3})\b/i.exec(plain);
    if (qtyM) {
      var qn = parseInt(qtyM[1] || qtyM[2] || qtyM[3], 10);
      if (qn >= 1 && qn <= 200) quantity = qn;
    }

    var weightGrams = 0;
    var wM = /(?:nang|khoi\s*luong|kl|tam|khoang)?\s*(\d+(?:[.,]\d+)?)\s*(kg|gram|gam|gr|g)\b/i.exec(plain);
    if (wM) {
      var rawN = parseFloat(wM[1].replace(',', '.'));
      var grams = wM[2].toLowerCase() === 'kg' ? rawN * 1000 : rawN;
      if (isFinite(grams) && grams > 0 && grams <= 50000) {
        var perPart = /(?:1\s*cai|moi\s*cai|moi\s*chiec|\/cai|\/chiec)/i.test(plain);
        weightGrams = Math.round((perPart ? grams * quantity : grams) * 10) / 10;
      }
    }

    var deliveryDeadline = getLocalDateYmd(3);
    if (/\b(?:hom\s*nay|trong\s*ngay|lay\s*lien)\b/.test(plain)) deliveryDeadline = getLocalDateYmd(0);
    else if (/\b(?:ngay\s*mai|mai\s*lay|mai\s*giao)\b/.test(plain)) deliveryDeadline = getLocalDateYmd(1);

    var urgency = calculateDeliveryUrgency(deliveryDeadline);
    var pricing = calculatePrint3DPrice(materials, material, weightGrams, quantity, urgency.surchargePercent);
    var depositAmount = pricing.totalAmount > 0 ? Math.round(pricing.totalAmount * 0.3) : 0;

    return {
      material: material,
      infill: infill,
      weightGrams: weightGrams,
      quantity: quantity,
      color: '',
      driveUrls: driveUrls,
      deliveryDeadline: deliveryDeadline,
      deliveryLabel: urgency.displayText,
      rushSurchargePercent: urgency.surchargePercent,
      subtotalAmount: pricing.subtotalAmount,
      rushFeeAmount: pricing.rushFeeAmount,
      totalAmount: pricing.totalAmount,
      depositAmount: depositAmount,
      codRemainingAmount: Math.max(0, pricing.totalAmount - depositAmount)
    };
  }

  function generateChatQuoteReply(lead, opts) {
    var mats = (opts && opts.materials && opts.materials.length > 0) ? opts.materials : DEFAULT_MATERIALS;
    var greetingName = lead.customerName && lead.customerName !== 'Khách chat' ? lead.customerName : 'bạn';
    var lines = ['Chào ' + greetingName + ', TeeBi & Robot (TBX Electrics) xin gửi báo giá chi tiết cho mình ạ:'];

    if (lead.matchedProducts && lead.matchedProducts.length > 0) {
      lines.push('');
      lines.push('📦 Mạch & Linh kiện:');
      for (var i = 0; i < lead.matchedProducts.length; i++) {
        var it = lead.matchedProducts[i];
        lines.push('• [' + it.code + '] ' + it.name + ' × ' + it.quantity + ' ' + it.unit + ' = ' + formatVnd(it.unitPrice * it.quantity));
      }
    }

    if (lead.print3d) {
      var p3d = lead.print3d;
      lines.push('');
      if (p3d.weightGrams > 0 && p3d.totalAmount > 0) {
        lines.push('🖨️ Dịch vụ In 3D khổ lớn (800×800mm):');
        lines.push('• Vật liệu: ' + p3d.material + ' · Infill ' + p3d.infill + ' · Tổng SL: ' + p3d.quantity);
        lines.push('• Khối lượng ước tính: ' + p3d.weightGrams + 'g' + (p3d.printTime ? ' · Thời gian in ~ ' + p3d.printTime : '') + (p3d.dimensions ? ' · KT: ' + p3d.dimensions : ''));
        lines.push('• Thời hạn: ' + p3d.deliveryLabel);
        lines.push('• Chi phí in 3D: ' + formatVnd(p3d.totalAmount));
        if (p3d.depositAmount > 0) {
          lines.push('• Thanh toán: Cọc 30% (' + formatVnd(p3d.depositAmount) + ') · Thu COD 70% (' + formatVnd(p3d.codRemainingAmount) + ') — hoặc CK 100% VietQR.');
        }
      } else {
        var rateTable = mats.map(function (m) {
          return m.name + ': ' + Number(m.pricePerGram || 0).toLocaleString('vi-VN') + 'đ/g';
        }).join(' | ');
        lines.push('🖨️ Báo giá In 3D theo yêu cầu (máy khổ lớn 800×800mm):');
        lines.push('• Bảng giá nhựa hiện tại: ' + rateTable);
        lines.push('• Vật liệu dự kiến: ' + p3d.material + ' · Infill ' + p3d.infill + ' · SL: ' + p3d.quantity);
        lines.push('• Bạn gửi giúp mình link Google Drive chứa file .STL/.ZIP (hoặc thả file trực tiếp tại https://trbach777.github.io/ -> mục In 3D) để hệ thống cắt lớp & báo giá chính xác trong 5 giây nhé!');
      }
    }

    if (lead.grandTotal > 0) {
      lines.push('');
      lines.push('💰 TỔNG CỘNG TẠM TÍNH: ' + formatVnd(lead.grandTotal));
    }
    if (lead.missingFields && lead.missingFields.length > 0) {
      lines.push('');
      lines.push('👉 Để Shop lên đơn ngay, bạn cho mình xin thêm ' + lead.missingFields.join(' & ') + ' nhé!');
    } else if ((lead.matchedProducts && lead.matchedProducts.length > 0) || (lead.print3d && lead.print3d.totalAmount > 0)) {
      lines.push('');
      lines.push('👉 Thông tin nhận hàng đã đầy đủ — bạn xác nhận OK để Shop chốt đơn và xử lý ngay nhé!');
    }
    lines.push((opts && opts.customFooterNote) || 'Hỗ trợ kỹ thuật / gửi file lớn nhanh qua Zalo: 0789 044 703.');
    return lines.join('\n');
  }

  function parseChatLead(rawText, opts) {
    var options = opts || {};
    var shopPhoneDigits = String(options.shopPhone || '0789044703').replace(/\D/g, '');
    var shopEmailLower = String(options.shopEmail || 'tranbach9805@gmail.com').trim().toLowerCase();
    var mats = (options.materials && options.materials.length > 0) ? options.materials : DEFAULT_MATERIALS;

    var platform = detectPlatform(rawText, options.platformHint);
    var customerText = extractCustomerOnlyText(rawText, shopPhoneDigits, shopEmailLower) || String(rawText || '').trim();
    var phones = extractValidPhones(customerText, shopPhoneDigits);
    var customerPhone = phones[0] || '';
    var customerEmail = extractEmail(customerText, shopEmailLower);
    var customerName = extractCustomerName(customerText, rawText, options.customerNameHint);
    var ship = extractShippingInfo(customerText, customerPhone);
    var orderCodeM = /(?:ma\s*don(?:\s*hang)?|order(?:\s*id)?)\s*[:#]?\s*([A-Z0-9_-]{8,24})/i.exec(stripVnTones(rawText));
    var matchedProducts = matchProductsFromText(customerText, options.products || []);
    var print3d = extractPrint3DSpec(customerText, mats);

    var hardwareTotal = matchedProducts.reduce(function (s, p) { return s + p.unitPrice * p.quantity; }, 0);
    var grandTotal = hardwareTotal + (print3d ? print3d.totalAmount : 0);

    var missingFields = [];
    if (!customerPhone) missingFields.push('SĐT nhận hàng');
    if (ship.shippingMethod === 'delivery' && !ship.shippingAddress) missingFields.push('địa chỉ giao hàng');

    var plain = stripVnTones(customerText).toLowerCase().trim();
    var hasClose = /\b(?:chot|dat\s*don|dat\s*hang|lay\s*(?:minh|cho|luon)|gui\s*(?:cho|ve|giup)|ship\s*(?:cho|ve|den)|len\s*don|mua)\b/.test(plain);
    var hasQuote = /\b(?:bao\s*gia|gia(?:\s*bao\s*nhieu)?|bao\s*nhieu|bn\s*tien|in\s*3d|stl|pla|petg|abs|tpu)\b/.test(plain);
    var hasSup = /\b(?:huong\s*dan|dau\s*noi|code|firmware|bao\s*hanh|loi|tu\s*van|con\s*hang)\b/.test(plain);

    var intent = 'support_inquiry';
    if (!plain) intent = 'noise';
    else if ((matchedProducts.length > 0 || print3d) && (customerPhone || ship.shippingAddress || hasClose)) intent = 'ready_order';
    else if (matchedProducts.length > 0 || print3d || hasQuote) intent = 'quote_request';
    else if (!hasSup && (plain.length <= 28 || /^(?:ok|oke|da|vang|cam\s*on|tks|hi|hello|alo|shop\s*oi)\b/.test(plain))) intent = 'noise';

    var lead = {
      id: 'CHAT-' + Date.now() + '-' + Math.floor(100 + Math.random() * 900),
      platform: platform,
      rawText: rawText,
      customerText: customerText,
      intent: intent,
      customerName: customerName,
      customerPhone: customerPhone,
      customerEmail: customerEmail,
      shippingMethod: ship.shippingMethod,
      shippingAddress: ship.shippingAddress,
      platformOrderCode: orderCodeM ? orderCodeM[1].toUpperCase() : '',
      matchedProducts: matchedProducts,
      print3d: print3d,
      hardwareTotal: hardwareTotal,
      grandTotal: grandTotal,
      paymentMethod: /\b(?:chuyen\s*khoan|vietqr|\bck\b)\b/.test(plain) && !/\bcod\b/.test(plain) ? 'transfer' : 'cod',
      missingFields: missingFields,
      createdAt: new Date().toISOString()
    };
    lead.suggestedReply = generateChatQuoteReply(lead, { materials: mats });
    return lead;
  }

  var api = {
    stripVnTones: stripVnTones,
    formatVnd: formatVnd,
    calculateDeliveryUrgency: calculateDeliveryUrgency,
    calculatePrint3DPrice: calculatePrint3DPrice,
    parseChatLead: parseChatLead,
    generateChatQuoteReply: generateChatQuoteReply
  };

  root.TBXChatParser = api;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
