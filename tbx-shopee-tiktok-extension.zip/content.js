(function () {
  if (window.__tbxShopeeTiktokHelperMounted) return;
  window.__tbxShopeeTiktokHelperMounted = true;

  var parser = window.TBXChatParser;
  if (!parser) return;

  var state = {
    open: false,
    catalog: null,
    currentLead: null,
    listLeads: [],
    activeSubTab: 'chat', // 'chat' | 'list'
    scanningDrive: false,
    pushingOrder: false,
    toast: '',
    manualNoteAdded: false
  };

  function detectHostPlatform() {
    var h = String(location.hostname || '').toLowerCase();
    if (h.indexOf('shopee') !== -1) return 'shopee';
    if (h.indexOf('tiktok') !== -1) return 'tiktok';
    return 'other';
  }

  function escHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function findLargestScrollableMessageArea() {
    var candidates = document.querySelectorAll(
      '[class*="message-list"], [class*="chat-content"], [class*="chat-body"], [class*="msg-list"], [data-e2e*="message-list"], main, [role="log"]'
    );
    var best = null;
    var bestArea = 0;
    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      if (!el || !el.getBoundingClientRect) continue;
      if (el.closest && el.closest('#tbx-chat-helper-host')) continue;
      var r = el.getBoundingClientRect();
      if (r.width < 220 || r.height < 180) continue;
      var area = r.width * r.height;
      if (area > bestArea) {
        bestArea = area;
        best = el;
      }
    }
    return best || document.body;
  }

  function extractCustomerNameFromDom(platform) {
    var selectors =
      platform === 'shopee'
        ? [
            '[class*="chat-header"] [class*="name"]',
            '[class*="conversation-header"] [class*="name"]',
            '[class*="active"] [class*="username"]',
            '[data-testid*="buyer-name"]',
            'header h1, header h2, header h3'
          ]
        : [
            '[data-e2e="chat-user-name"]',
            '[class*="chat-header"] [class*="name"]',
            '[class*="buyer"] [class*="name"]',
            '[class*="conversation-title"]',
            'header h1, header h2, header h3'
          ];

    for (var i = 0; i < selectors.length; i++) {
      var els = document.querySelectorAll(selectors[i]);
      for (var j = 0; j < els.length; j++) {
        var el = els[j];
        if (!el || (el.closest && el.closest('#tbx-chat-helper-host'))) continue;
        var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
        if (!rect || rect.width === 0 || rect.height === 0 || rect.top > 180) continue;
        var txt = String(el.innerText || el.textContent || '').trim().split('\n')[0].trim();
        if (txt.length >= 2 && txt.length <= 50 && !/shopee|tiktok|chat|tin nhắn|seller/i.test(txt)) {
          return txt;
        }
      }
    }
    return '';
  }

  function extractBuyerMessagesFromDom(platform) {
    var area = findLargestScrollableMessageArea();
    var areaRect = area && area.getBoundingClientRect ? area.getBoundingClientRect() : { left: 0, width: window.innerWidth };
    var nodes = area.querySelectorAll(
      '[class*="message-item"], [class*="msg-item"], [class*="chat-item"], [class*="bubble"], [class*="message-content"], [data-e2e*="message"]'
    );
    var lines = [];
    var seen = {};

    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!el || (el.closest && el.closest('#tbx-chat-helper-host'))) continue;
      if (el.querySelector && el.querySelector('[class*="message-item"], [class*="msg-item"]')) continue;
      var txt = String(el.innerText || el.textContent || '').trim();
      if (!txt || txt.length < 2 || txt.length > 1500) continue;
      if (seen[txt]) continue;

      var cls = String(el.className || '').toLowerCase();
      var parentCls = el.parentElement ? String(el.parentElement.className || '').toLowerCase() : '';
      var combinedCls = cls + ' ' + parentCls;

      var isSeller =
        /(?:mine|self|right|outbound|seller|owner|outgoing|me\b)/.test(combinedCls) ||
        el.getAttribute('data-is-self') === 'true' ||
        el.getAttribute('data-sender') === 'seller';

      if (!isSeller && areaRect.width > 240 && el.getBoundingClientRect) {
        var r = el.getBoundingClientRect();
        var centerX = r.left + r.width / 2;
        if (centerX > areaRect.left + areaRect.width * 0.58 && r.width < areaRect.width * 0.72) {
          isSeller = true;
        }
      }

      if (!isSeller && el.querySelectorAll) {
        var imgs = el.querySelectorAll('a[href]');
        for (var a = 0; a < imgs.length; a++) {
          var href = imgs[a].getAttribute('href') || '';
          if (href.indexOf('drive.google.com') !== -1 && txt.indexOf(href) === -1) {
            txt += '\n' + href;
          }
        }
      }

      seen[txt] = true;
      if (!isSeller) {
        lines.push('Khách: ' + txt);
      }
    }

    if (lines.length === 0) {
      var fallbackName = extractCustomerNameFromDom(platform);
      var rawFallback = String((area && area.innerText) || '').trim();
      if (rawFallback.length > 1800) rawFallback = rawFallback.slice(-1800);
      return (fallbackName ? '[' + platform + '] ' + fallbackName + ':\n' : '') + rawFallback;
    }

    var custName = extractCustomerNameFromDom(platform);
    var prefix = custName ? '[' + platform + '] Tên: ' + custName + '\n' : '[' + platform + ']\n';
    return prefix + lines.slice(-18).join('\n');
  }

  function scanConversationListDom(platform) {
    var listItems = document.querySelectorAll(
      '[class*="conversation-item"], [class*="session-item"], [class*="chat-list"] > div, [data-e2e*="chat-item"]'
    );
    var out = [];
    var seen = {};
    var cat = state.catalog || {};

    for (var i = 0; i < listItems.length; i++) {
      var el = listItems[i];
      if (!el || (el.closest && el.closest('#tbx-chat-helper-host'))) continue;
      var txt = String(el.innerText || el.textContent || '').trim();
      if (!txt || txt.length < 4 || txt.length > 400 || seen[txt]) continue;
      seen[txt] = true;
      var parts = txt.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
      var title = parts[0] || 'Khách chat';
      var bodyText = parts.slice(1).join(' ');
      if (!bodyText) continue;

      var parsed = parser.parseChatLead(txt, {
        products: cat.products || [],
        materials: cat.print3dMaterials,
        platformHint: platform,
        customerNameHint: title,
        shopPhone: cat.profile && cat.profile.phone,
        shopEmail: cat.profile && cat.profile.email
      });
      if (parsed.intent !== 'noise' || parsed.matchedProducts.length > 0 || parsed.print3d) {
        parsed._sourceEl = el;
        out.push(parsed);
      }
      if (out.length >= 20) break;
    }
    return out;
  }

  function insertTextIntoActiveChatInput(text) {
    var selectors = [
      'textarea:not([readonly]):not([disabled])',
      'div[contenteditable="true"]',
      '[role="textbox"][contenteditable="true"]',
      '[data-e2e*="chat-input"]'
    ];
    var bestEl = null;
    var bestScore = -1;
    for (var i = 0; i < selectors.length; i++) {
      var list = document.querySelectorAll(selectors[i]);
      for (var j = 0; j < list.length; j++) {
        var el = list[j];
        if (!el || (el.closest && el.closest('#tbx-chat-helper-host'))) continue;
        var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
        if (!rect || rect.width < 120 || rect.height < 20) continue;
        var score = rect.top + rect.width;
        if (score > bestScore) {
          bestScore = score;
          bestEl = el;
        }
      }
    }
    if (!bestEl) return false;

    bestEl.focus();
    if (bestEl.tagName === 'TEXTAREA' || bestEl.tagName === 'INPUT') {
      var proto = bestEl.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) desc.set.call(bestEl, text);
      else bestEl.value = text;
      bestEl.dispatchEvent(new Event('input', { bubbles: true }));
      bestEl.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }

    try {
      var sel = window.getSelection();
      var range = document.createRange();
      range.selectNodeContents(bestEl);
      sel.removeAllRanges();
      sel.addRange(range);
      if (document.execCommand) {
        document.execCommand('insertText', false, text);
      } else {
        bestEl.textContent = text;
      }
    } catch (e) {
      bestEl.textContent = text;
    }
    bestEl.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    return true;
  }

  // Mount isolated Shadow DOM UI
  var host = document.createElement('div');
  host.id = 'tbx-chat-helper-host';
  host.style.cssText = 'position:fixed;right:18px;bottom:22px;z-index:2147483647;font-family:system-ui,-apple-system,sans-serif;';
  document.documentElement.appendChild(host);

  var shadow = host.attachShadow({ mode: 'open' });
  shadow.innerHTML = [
    '<style>',
    '*{box-sizing:border-box;font-family:system-ui,-apple-system,sans-serif;}',
    '.pill{display:flex;align-items:center;gap:8px;background:linear-gradient(135deg,#0284c7,#0f172a);color:#fff;border:1px solid #38bdf8;border-radius:999px;padding:10px 16px;font-weight:700;font-size:13px;cursor:pointer;box-shadow:0 10px 28px rgba(2,132,199,.45);}',
    '.drawer{width:385px;max-width:94vw;max-height:85vh;background:#0b1324;color:#e2e8f0;border:1px solid #1e3a8a;border-radius:14px;box-shadow:0 20px 50px rgba(0,0,0,.6);display:none;flex-direction:column;overflow:hidden;}',
    '.drawer.open{display:flex;}',
    '.hdr{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#0f172a;border-bottom:1px solid #1e325c;}',
    '.hdr-title{font-weight:800;font-size:13px;color:#38bdf8;}',
    '.tabs{display:flex;border-bottom:1px solid #1e325c;background:#0f1930;}',
    '.tab{flex:1;padding:8px;font-size:11px;font-weight:700;background:none;border:none;color:#94a3b8;cursor:pointer;border-bottom:2px solid transparent;}',
    '.tab.active{color:#38bdf8;border-bottom-color:#38bdf8;background:#0b1324;}',
    '.body{padding:12px;overflow-y:auto;flex:1;font-size:12px;display:flex;flex-direction:column;gap:8px;}',
    '.card{background:#111c33;border:1px solid #1e325c;border-radius:10px;padding:9px;display:flex;flex-direction:column;gap:6px;}',
    '.row{display:flex;gap:6px;align-items:center;}',
    '.col{flex:1;display:flex;flex-direction:column;gap:3px;}',
    'label{font-size:10px;color:#94a3b8;font-weight:600;}',
    'input,select,textarea{width:100%;background:#0b1324;color:#f8fafc;border:1px solid #243b6b;border-radius:6px;padding:5px 7px;font-size:11px;}',
    'textarea{resize:vertical;line-height:1.4;}',
    'button{border:none;border-radius:7px;padding:7px 10px;font-weight:700;font-size:11px;cursor:pointer;}',
    '.btn-sky{background:#0ea5e9;color:#082f49;}',
    '.btn-green{background:#10b981;color:#022c22;}',
    '.btn-amber{background:#f59e0b;color:#271500;}',
    '.btn-slate{background:#1e293b;color:#e2e8f0;border:1px solid #334155;}',
    '.badge{display:inline-block;padding:2px 7px;border-radius:999px;font-size:10px;font-weight:700;}',
    '.b-ready{background:rgba(16,185,129,.2);color:#34d399;border:1px solid rgba(16,185,129,.4);}',
    '.b-quote{background:rgba(14,165,233,.2);color:#38bdf8;border:1px solid rgba(14,165,233,.4);}',
    '.b-noise{background:rgba(100,116,139,.2);color:#94a3b8;}',
    '.toast{background:#022c22;border:1px solid #10b981;color:#6ee7b7;padding:6px 10px;border-radius:8px;font-size:11px;font-weight:600;}',
    '</style>',
    '<button id="tbxPill" class="pill">🤖 TBX Báo Giá <span id="tbxPillBadge" class="badge b-quote">Sẵn sàng</span></button>',
    '<div id="tbxDrawer" class="drawer">',
    '  <div class="hdr">',
    '    <span class="hdr-title">🤖 TBX · Lọc Tin &amp; Báo Giá</span>',
    '    <div class="row">',
    '      <button id="tbxRescan" class="btn-slate" style="padding:4px 8px;">🔍 Quét lại</button>',
    '      <button id="tbxClose" class="btn-slate" style="padding:4px 8px;">✕</button>',
    '    </div>',
    '  </div>',
    '  <div class="tabs">',
    '    <button id="tabChat" class="tab active">💬 Khung chat hiện tại</button>',
    '    <button id="tabList" class="tab">📂 Lọc DS chat (<span id="listCount">0</span>)</button>',
    '  </div>',
    '  <div id="tbxBody" class="body"></div>',
    '</div>'
  ].join('');

  var pillEl = shadow.getElementById('tbxPill');
  var pillBadgeEl = shadow.getElementById('tbxPillBadge');
  var drawerEl = shadow.getElementById('tbxDrawer');
  var bodyEl = shadow.getElementById('tbxBody');
  var listCountEl = shadow.getElementById('listCount');

  function showToast(msg) {
    state.toast = msg;
    render();
    setTimeout(function () {
      if (state.toast === msg) {
        state.toast = '';
        render();
      }
    }, 3500);
  }

  function rebuildReply(lead) {
    var cat = state.catalog || {};
    var hwTotal = (lead.matchedProducts || []).reduce(function (s, p) { return s + p.unitPrice * p.quantity; }, 0);
    if (lead.print3d) {
      var urg = parser.calculateDeliveryUrgency(lead.print3d.deliveryDeadline);
      var pr = parser.calculatePrint3DPrice(cat.print3dMaterials, lead.print3d.material, lead.print3d.weightGrams, lead.print3d.quantity, urg.surchargePercent);
      lead.print3d.deliveryLabel = urg.displayText;
      lead.print3d.rushSurchargePercent = urg.surchargePercent;
      lead.print3d.subtotalAmount = pr.subtotalAmount;
      lead.print3d.rushFeeAmount = pr.rushFeeAmount;
      lead.print3d.totalAmount = pr.totalAmount;
      lead.print3d.depositAmount = pr.totalAmount > 0 ? Math.round(pr.totalAmount * 0.3) : 0;
      lead.print3d.codRemainingAmount = Math.max(0, pr.totalAmount - lead.print3d.depositAmount);
    }
    lead.hardwareTotal = hwTotal;
    lead.grandTotal = hwTotal + (lead.print3d ? lead.print3d.totalAmount : 0);
    var miss = [];
    if (!lead.customerPhone) miss.push('SĐT nhận hàng');
    if (lead.shippingMethod === 'delivery' && !lead.shippingAddress) miss.push('địa chỉ giao hàng');
    lead.missingFields = miss;
    lead.suggestedReply = parser.generateChatQuoteReply(lead, { materials: cat.print3dMaterials });
  }

  function runCurrentScan(manualText) {
    var platform = detectHostPlatform();
    var text = typeof manualText === 'string' ? manualText : extractBuyerMessagesFromDom(platform);
    var cat = state.catalog || {};
    var lead = parser.parseChatLead(text, {
      products: cat.products || [],
      materials: cat.print3dMaterials,
      platformHint: platform,
      customerNameHint: extractCustomerNameFromDom(platform),
      shopPhone: cat.profile && cat.profile.phone,
      shopEmail: cat.profile && cat.profile.email
    });
    state.currentLead = lead;

    if (lead.intent === 'ready_order') {
      pillBadgeEl.className = 'badge b-ready';
      pillBadgeEl.textContent = 'Chốt đơn';
    } else if (lead.intent === 'quote_request') {
      pillBadgeEl.className = 'badge b-quote';
      pillBadgeEl.textContent = 'Hỏi giá';
    } else {
      pillBadgeEl.className = 'badge b-noise';
      pillBadgeEl.textContent = 'Sẵn sàng';
    }

    state.listLeads = scanConversationListDom(platform);
    listCountEl.textContent = String(state.listLeads.length);
    render();
  }

  function render() {
    if (!state.open) return;
    var lead = state.currentLead;
    var cat = state.catalog || {};
    var mats = (cat.print3dMaterials && cat.print3dMaterials.length) ? cat.print3dMaterials : [
      { name: 'PLA' }, { name: 'PETG' }, { name: 'ABS' }, { name: 'TPU' }, { name: 'Cacbon CF' }
    ];

    if (state.activeSubTab === 'list') {
      var listHtml = state.listLeads.length === 0
        ? '<div class="card">Chưa lọc thấy cuộc chat nào hỏi giá/đặt hàng trong danh sách đang hiển thị. Hãy cuộn danh sách chat hoặc bấm Quét lại.</div>'
        : state.listLeads.map(function (it, idx) {
            var badgeCls = it.intent === 'ready_order' ? 'b-ready' : 'b-quote';
            var badgeTxt = it.intent === 'ready_order' ? 'Sẵn sàng lên đơn' : 'Hỏi báo giá';
            return '<div class="card">' +
              '<div class="row" style="justify-content:space-between;">' +
                '<strong>' + escHtml(it.customerName) + '</strong>' +
                '<span class="badge ' + badgeCls + '">' + badgeTxt + '</span>' +
              '</div>' +
              '<div style="color:#94a3b8;font-size:11px;">' + escHtml(String(it.customerText || '').slice(0, 110)) + '</div>' +
              '<button class="btn-sky tbx-open-chat" data-idx="' + idx + '">Mở hội thoại này</button>' +
            '</div>';
          }).join('');
      bodyEl.innerHTML = (state.toast ? '<div class="toast">' + escHtml(state.toast) + '</div>' : '') + listHtml;
      var openBtns = bodyEl.querySelectorAll('.tbx-open-chat');
      openBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var item = state.listLeads[Number(btn.getAttribute('data-idx'))];
          if (item && item._sourceEl && item._sourceEl.click) {
            item._sourceEl.click();
            state.activeSubTab = 'chat';
            setTimeout(function () { runCurrentScan(); }, 700);
          }
        });
      });
      return;
    }

    if (!lead) {
      bodyEl.innerHTML = '<div class="card">Đang đọc tin nhắn...</div>';
      return;
    }

    var intentBadge = lead.intent === 'ready_order'
      ? '<span class="badge b-ready">✓ Sẵn sàng lên đơn</span>'
      : lead.intent === 'quote_request'
        ? '<span class="badge b-quote">💬 Hỏi báo giá</span>'
        : '<span class="badge b-noise">Khác / Chưa rõ đơn</span>';

    var prodHtml = (lead.matchedProducts || []).length > 0
      ? '<div class="card"><label>MẠCH / LINH KIỆN NHẬN DIỆN</label>' +
        lead.matchedProducts.map(function (p, pi) {
          return '<div class="row" style="justify-content:space-between;">' +
            '<span style="flex:1;font-size:11px;"><strong>' + escHtml(p.code) + '</strong> · ' + escHtml(parser.formatVnd(p.unitPrice)) + '</span>' +
            '<input type="number" min="1" value="' + p.quantity + '" data-pidx="' + pi + '" class="tbx-pqty" style="width:52px;text-align:center;" />' +
          '</div>';
        }).join('') +
        '</div>'
      : '';

    var p3dHtml = lead.print3d ? (
      '<div class="card">' +
      '<div class="row" style="justify-content:space-between;"><label>THÔNG SỐ IN 3D</label><strong style="color:#38bdf8;">' + escHtml(parser.formatVnd(lead.print3d.totalAmount)) + '</strong></div>' +
      (lead.print3d.driveUrls && lead.print3d.driveUrls[0]
        ? '<div class="row"><input id="tbxDriveUrl" value="' + escHtml(lead.print3d.driveUrls[0]) + '" /><button id="tbxScanDrive" class="btn-amber" style="white-space:nowrap;">' + (state.scanningDrive ? 'Đang quét...' : 'Quét STL') + '</button></div>'
        : '') +
      '<div class="row">' +
        '<div class="col"><label>Vật liệu</label><select id="tbxMat">' + mats.map(function (m) {
          return '<option value="' + escHtml(m.name) + '"' + (m.name === lead.print3d.material ? ' selected' : '') + '>' + escHtml(m.name) + '</option>';
        }).join('') + '</select></div>' +
        '<div class="col"><label>Gam (tổng)</label><input id="tbxGram" type="number" min="0" value="' + lead.print3d.weightGrams + '" /></div>' +
        '<div class="col"><label>SL</label><input id="tbx3dQty" type="number" min="1" value="' + lead.print3d.quantity + '" /></div>' +
      '</div>' +
      (lead.print3d.depositAmount > 0 ? '<div style="font-size:10px;color:#fbbf24;">Cọc 30%: ' + escHtml(parser.formatVnd(lead.print3d.depositAmount)) + ' · Thu COD: ' + escHtml(parser.formatVnd(lead.print3d.codRemainingAmount)) + '</div>' : '') +
      '</div>'
    ) : '';

    bodyEl.innerHTML = [
      state.toast ? '<div class="toast">' + escHtml(state.toast) + '</div>' : '',
      '<div class="row" style="justify-content:space-between;"><span>Nguồn: <strong>' + escHtml(lead.platform.toUpperCase()) + '</strong></span>' + intentBadge + '</div>',
      '<div class="card">',
        '<label>TIN KHÁCH GỬI (có thể dán/sửa thêm nếu cần)</label>',
        '<textarea id="tbxRaw" rows="3"></textarea>',
        '<button id="tbxReparse" class="btn-slate">Phân tích lại đoạn tin trên</button>',
      '</div>',
      '<div class="card">',
        '<div class="row">',
          '<div class="col"><label>Khách hàng</label><input id="tbxName" /></div>',
          '<div class="col"><label>SĐT (10 số)</label><input id="tbxPhone" /></div>',
        '</div>',
        '<div class="col"><label>Địa chỉ giao hàng</label><input id="tbxAddr" /></div>',
      '</div>',
      prodHtml,
      p3dHtml,
      '<div class="card">',
        '<div class="row" style="justify-content:space-between;"><label>MẪU TIN BÁO GIÁ TỰ ĐỘNG</label><strong style="color:#34d399;">' + escHtml(parser.formatVnd(lead.grandTotal)) + '</strong></div>',
        '<textarea id="tbxReply" rows="6"></textarea>',
        '<div class="row">',
          '<button id="tbxInsert" class="btn-sky">✍️ Chèn vào ô chat</button>',
          '<button id="tbxCopy" class="btn-slate">📋 Copy</button>',
        '</div>',
        '<button id="tbxPushOrder" class="btn-green"' + (state.pushingOrder ? ' disabled' : '') + '>' +
          (state.pushingOrder ? 'Đang đẩy đơn lên Google Sheet...' : '🚀 Tạo đơn → Sheet DonHang' + (lead.print3d ? ' (Chờ duyệt)' : '')) +
        '</button>',
      '</div>'
    ].join('');

    shadow.getElementById('tbxRaw').value = lead.rawText || '';
    shadow.getElementById('tbxName').value = lead.customerName || '';
    shadow.getElementById('tbxPhone').value = lead.customerPhone || '';
    shadow.getElementById('tbxAddr').value = lead.shippingAddress || '';
    shadow.getElementById('tbxReply').value = lead.suggestedReply || '';

    shadow.getElementById('tbxReparse').addEventListener('click', function () {
      runCurrentScan(shadow.getElementById('tbxRaw').value);
    });

    ['tbxName', 'tbxPhone', 'tbxAddr'].forEach(function (id) {
      shadow.getElementById(id).addEventListener('input', function () {
        lead.customerName = shadow.getElementById('tbxName').value;
        lead.customerPhone = shadow.getElementById('tbxPhone').value;
        lead.shippingAddress = shadow.getElementById('tbxAddr').value;
        rebuildReply(lead);
        shadow.getElementById('tbxReply').value = lead.suggestedReply;
      });
    });

    bodyEl.querySelectorAll('.tbx-pqty').forEach(function (inp) {
      inp.addEventListener('change', function () {
        var i = Number(inp.getAttribute('data-pidx'));
        if (lead.matchedProducts[i]) {
          lead.matchedProducts[i].quantity = Math.max(1, Number(inp.value) || 1);
          rebuildReply(lead);
          render();
        }
      });
    });

    var matEl = shadow.getElementById('tbxMat');
    var gramEl = shadow.getElementById('tbxGram');
    var q3dEl = shadow.getElementById('tbx3dQty');
    if (matEl && gramEl && q3dEl && lead.print3d) {
      var update3d = function () {
        lead.print3d.material = matEl.value;
        lead.print3d.weightGrams = Math.max(0, Number(gramEl.value) || 0);
        lead.print3d.quantity = Math.max(1, Number(q3dEl.value) || 1);
        rebuildReply(lead);
        render();
      };
      matEl.addEventListener('change', update3d);
      gramEl.addEventListener('change', update3d);
      q3dEl.addEventListener('change', update3d);
    }

    var scanBtn = shadow.getElementById('tbxScanDrive');
    if (scanBtn && lead.print3d) {
      scanBtn.addEventListener('click', async function () {
        var u = shadow.getElementById('tbxDriveUrl').value.trim();
        if (!u) return;
        state.scanningDrive = true;
        render();
        var res = await chrome.runtime.sendMessage({
          type: 'SCAN_3D_LINK',
          fileUrl: u,
          material: lead.print3d.material,
          quantity: lead.print3d.quantity,
          infill: lead.print3d.infill
        });
        state.scanningDrive = false;
        if (res && res.ok && res.totalWeightGrams > 0) {
          lead.print3d.weightGrams = res.totalWeightGrams;
          lead.print3d.dimensions = res.dimensions || '';
          lead.print3d.printTime = res.printTime || '';
          rebuildReply(lead);
          showToast('✓ Quét STL thành công: ' + res.totalWeightGrams + 'g (' + parser.formatVnd(lead.print3d.totalAmount) + ')');
        } else {
          showToast((res && res.error) || 'Không quét được file Drive.');
        }
      });
    }

    shadow.getElementById('tbxInsert').addEventListener('click', function () {
      var text = shadow.getElementById('tbxReply').value;
      var ok = insertTextIntoActiveChatInput(text);
      showToast(ok ? '✓ Đã chèn vào ô chat (hãy kiểm tra rồi bấm Gửi)!' : 'Không tìm thấy ô nhập chat — bấm Copy để dán tay.');
    });

    shadow.getElementById('tbxCopy').addEventListener('click', function () {
      navigator.clipboard.writeText(shadow.getElementById('tbxReply').value);
      showToast('✓ Đã copy tin báo giá!');
    });

    shadow.getElementById('tbxPushOrder').addEventListener('click', async function () {
      if (lead.matchedProducts.length === 0 && !lead.print3d) {
        showToast('Chưa nhận diện thấy sản phẩm hay yêu cầu In 3D nào.');
        return;
      }
      state.pushingOrder = true;
      render();
      var platTag = '[' + lead.platform.toUpperCase() + ']';
      var now = new Date();
      var pad = function (n) { return String(n).padStart(2, '0'); };
      var ymd = String(now.getFullYear()).slice(-2) + pad(now.getMonth() + 1) + pad(now.getDate());
      var rand = String(Math.floor(100 + Math.random() * 900));

      try {
        if (lead.print3d && (!lead.matchedProducts || lead.matchedProducts.length === 0)) {
          var p3dId = '3D-' + ymd + '-' + rand;
          var resp = await chrome.runtime.sendMessage({
            type: 'CREATE_PRINT3D_ORDER',
            payload: {
              id: p3dId,
              customerName: lead.customerName || 'Khách chat',
              customerPhone: lead.customerPhone || '',
              customerEmail: lead.customerEmail || '',
              material: lead.print3d.material,
              infill: lead.print3d.infill,
              weightGrams: lead.print3d.weightGrams,
              quantity: lead.print3d.quantity,
              totalAmount: lead.print3d.totalAmount,
              driveFileUrl: (lead.print3d.driveUrls && lead.print3d.driveUrls[0]) || '',
              shippingMethod: lead.shippingMethod,
              shippingAddress: lead.shippingAddress || 'Chờ khách bổ sung địa chỉ',
              paymentMethod: 'cod',
              paymentStatus: 'cod_unpaid',
              depositAmount: lead.print3d.depositAmount,
              codRemainingAmount: lead.print3d.codRemainingAmount,
              deliveryDeadline: lead.print3d.deliveryDeadline,
              deliveryLabel: lead.print3d.deliveryLabel,
              note: platTag + (lead.platformOrderCode ? ' Đơn sàn: ' + lead.platformOrderCode : ''),
              autoQuoteEmail: false
            }
          });
          showToast(resp && resp.ok ? '✓ Đã đẩy đơn ' + p3dId + ' vào sheet DonHang (Chờ duyệt)!' : 'Lỗi đẩy đơn: ' + (resp && resp.error));
        } else {
          var ordId = 'DH-' + ymd + '-' + rand;
          var items = (lead.matchedProducts || []).map(function (p) {
            return {
              productId: p.productId,
              code: p.code,
              name: p.name,
              unitPrice: p.unitPrice,
              costPrice: p.costPrice,
              quantity: p.quantity,
              unit: p.unit
            };
          });
          if (lead.print3d) {
            items.push({
              productId: 'custom-3d-printing-service',
              code: 'IN3D',
              name: 'In 3D ' + lead.print3d.material + ' (' + lead.print3d.weightGrams + 'g)',
              unitPrice: lead.print3d.totalAmount,
              costPrice: 0,
              quantity: 1,
              unit: 'Đơn'
            });
          }
          var ordResp = await chrome.runtime.sendMessage({
            type: 'CREATE_PRODUCT_ORDER',
            order: {
              id: ordId,
              createdAt: now.toISOString(),
              customerName: platTag + ' ' + (lead.customerName || 'Khách chat'),
              customerPhone: lead.customerPhone || '',
              customerEmail: lead.customerEmail || '',
              shippingAddress: lead.shippingAddress || 'Chờ bổ sung địa chỉ',
              paymentMethod: lead.paymentMethod,
              paymentStatus: lead.paymentMethod === 'transfer' ? 'qr_reported' : 'cod_unpaid',
              status: 'pending',
              totalAmount: lead.grandTotal,
              items: items
            }
          });
          showToast(ordResp && ordResp.ok ? '✓ Đã ghi đơn ' + ordId + ' vào DonHang & báo Telegram!' : 'Lỗi đẩy đơn: ' + (ordResp && ordResp.error));
        }
      } finally {
        state.pushingOrder = false;
        render();
      }
    });
  }

  pillEl.addEventListener('click', async function () {
    state.open = true;
    drawerEl.classList.add('open');
    pillEl.style.display = 'none';
    if (!state.catalog) {
      var res = await chrome.runtime.sendMessage({ type: 'GET_CATALOG' });
      if (res && res.catalog) state.catalog = res.catalog;
    }
    runCurrentScan();
  });

  shadow.getElementById('tbxClose').addEventListener('click', function () {
    state.open = false;
    drawerEl.classList.remove('open');
    pillEl.style.display = 'flex';
  });

  shadow.getElementById('tbxRescan').addEventListener('click', function () {
    runCurrentScan();
    showToast('✓ Đã quét lại cuộc hội thoại!');
  });

  shadow.getElementById('tabChat').addEventListener('click', function () {
    state.activeSubTab = 'chat';
    shadow.getElementById('tabChat').classList.add('active');
    shadow.getElementById('tabList').classList.remove('active');
    render();
  });

  shadow.getElementById('tabList').addEventListener('click', function () {
    state.activeSubTab = 'list';
    shadow.getElementById('tabList').classList.add('active');
    shadow.getElementById('tabChat').classList.remove('active');
    runCurrentScan();
  });

  // Load initial catalog & observe chat switching cleanly
  chrome.runtime.sendMessage({ type: 'GET_CATALOG' }).then(function (res) {
    if (res && res.catalog) state.catalog = res.catalog;
    runCurrentScan();
  }).catch(function () {});

  var debounceTimer = null;
  var observer = new MutationObserver(function () {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(function () {
      if (state.open && state.activeSubTab === 'chat') return;
      runCurrentScan();
    }, 900);
  });
  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  }
})();
