const DEFAULT_CATALOG_URL = 'https://trbach777.github.io/cms-data.json';
const DEFAULT_WEBHOOK_URL =
  'https://script.google.com/macros/s/AKfycbxlfBa0eDSAt1Vu4a91EcGffsxHP0TaB0ESG6hCGQgRIBUsYIr6Uq-y9bcDn5_0fdA/exec';

const FALLBACK_CATALOG = {
  profile: {
    name: 'TeeBi & Robot',
    phone: '0789044703',
    email: 'tranbach9805@gmail.com',
    orderWebhookUrl: DEFAULT_WEBHOOK_URL,
  },
  print3dSetup: {
    printerModel: 'Creality Khổ Lớn 800×800 (0.4 nozzle)',
    nozzleMm: 0.4,
    layerHeightMm: 0.2,
    wallLoops: 3,
    topBottomLayers: 4,
    infillPercent: 20,
    supportEnabled: true,
    maxBuildX: 800,
    maxBuildY: 800,
    maxBuildZ: 800,
    defaultShopCommissionPercent: 25,
  },
  print3dMaterials: [
    { id: 'pla', name: 'PLA', pricePerGram: 800, costPricePerGram: 250, baseFee: 0 },
    { id: 'petg', name: 'PETG', pricePerGram: 400, costPricePerGram: 200, baseFee: 0 },
    { id: 'abs', name: 'ABS', pricePerGram: 1300, costPricePerGram: 300, baseFee: 0 },
    { id: 'tpu', name: 'TPU', pricePerGram: 1600, costPricePerGram: 450, baseFee: 0 },
    { id: 'carbon-cf', name: 'Cacbon CF', pricePerGram: 30000, costPricePerGram: 1500, baseFee: 0 },
  ],
  products: [
    { id: 'h743-core', code: 'H743ZIT6', name: { vi: 'Bo Điều khiển Trung tâm Robot Mecanum STM32H743' }, price: 1800000, costPrice: 950000, stock: 3, unit: 'Bo' },
    { id: 'pidsm-dc-servo', code: 'PIDSM-V2.2', name: { vi: 'Mạch Driver Động cơ DC Servo Encoder (PIDSM v2.2)' }, price: 450000, costPrice: 260000, stock: 15, unit: 'Mạch' },
    { id: 'imu-stmv2', code: 'IMU-STMV2', name: { vi: 'Module Xử lý Cảm biến Quán tính 6 trục Chống nhảy góc (IMU_STMv2)' }, price: 390000, costPrice: 210000, stock: 7, unit: 'Module' },
    { id: 'gamepad-ble', code: 'GAMEPAD-BLE', name: { vi: 'Bộ Thu Phát Tay cầm Điều khiển Robot Không dây (GamepadBLE)' }, price: 620000, costPrice: 360000, stock: 10, unit: 'Bộ' },
    { id: 'input-code-f4', code: 'INPUT-F4-IO', name: { vi: 'Board Đọc Cảm biến Laser & Công tắc hành trình Cách ly 24V (INPUT_CODE)' }, price: 420000, costPrice: 220000, stock: 9, unit: 'Board' },
    { id: 'mecanum-wheel-152', code: 'MECANUM-AL152', name: { vi: 'Bộ 4 Bánh xe Mecanum Hợp kim Nhôm Đúc 152mm Tải nặng' }, price: 2850000, costPrice: 2050000, stock: 6, unit: 'Bộ 4 bánh' },
    { id: 'dc-motor-24v-enc', code: 'MOTOR-24V-ENC', name: { vi: 'Động cơ Giảm tốc 24V DC Mô-men cao Tích hợp Encoder' }, price: 780000, costPrice: 540000, stock: 14, unit: 'Động cơ' },
    { id: 'laser-sensor-ind', code: 'LZR-IND-05V', name: { vi: 'Cảm biến Đo khoảng cách Laser Công nghiệp Ngõ ra 0–5V' }, price: 650000, costPrice: 430000, stock: 9, unit: 'Cảm biến' },
    { id: 'kit-agv-mecanum', code: 'KIT-AGV-MEC4', name: { vi: 'Bộ Mô hình Xe Robot Tự Hành AGV 4 Bánh Mecanum Bám Điểm Lidar & IMU' }, price: 22700000, costPrice: 12800000, stock: 1, unit: 'Bộ hoàn chỉnh' },
    { id: 'kit-pid-servo-lab', code: 'KIT-SERVO-LAB', name: { vi: 'Bộ Kit Thực Hành Điều Khiển Động Cơ DC Servo PID' }, price: 1900000, costPrice: 1120000, stock: 5, unit: 'Bộ Kit' },
    { id: 'kit-conveyor-sort', code: 'KIT-SORT-ARM', name: { vi: 'Mô Hình Băng Tải & Cơ Cấu Phân Loại Sản Phẩm Tự Động' }, price: 5000000, costPrice: 3100000, stock: 3, unit: 'Mô hình' },
  ],
};

async function getConfig() {
  const stored = await chrome.storage.local.get(['tbx_catalog_url', 'tbx_webhook_url']);
  return {
    catalogUrl: stored.tbx_catalog_url || DEFAULT_CATALOG_URL,
    webhookUrl: stored.tbx_webhook_url || '',
  };
}

async function fetchLiveCatalog(forceRefresh = false) {
  const cached = await chrome.storage.local.get(['tbx_catalog_cache', 'tbx_catalog_ts', 'tbx_catalog_url', 'tbx_webhook_url']);
  const now = Date.now();
  if (!forceRefresh && cached.tbx_catalog_cache && cached.tbx_catalog_ts && now - cached.tbx_catalog_ts < 15 * 60 * 1000) {
    return {
      ok: true,
      catalog: cached.tbx_catalog_cache,
      webhookUrl: cached.tbx_webhook_url || cached.tbx_catalog_cache?.profile?.orderWebhookUrl || DEFAULT_WEBHOOK_URL,
      cachedAt: cached.tbx_catalog_ts,
    };
  }

  const catalogUrl = cached.tbx_catalog_url || DEFAULT_CATALOG_URL;
  try {
    const res = await fetch(catalogUrl + '?t=' + now, { cache: 'no-store' });
    if (res.ok) {
      const json = await res.json();
      if (json && Array.isArray(json.products)) {
        const webhookUrl = cached.tbx_webhook_url || json.profile?.orderWebhookUrl || json.profile?.paymentCheckUrl || DEFAULT_WEBHOOK_URL;
        await chrome.storage.local.set({
          tbx_catalog_cache: json,
          tbx_catalog_ts: now,
        });
        return { ok: true, catalog: json, webhookUrl, cachedAt: now };
      }
    }
  } catch (err) {
    // Fallback to stale cache or embedded catalog
  }

  const catalog = cached.tbx_catalog_cache || FALLBACK_CATALOG;
  const webhookUrl = cached.tbx_webhook_url || catalog?.profile?.orderWebhookUrl || DEFAULT_WEBHOOK_URL;
  return { ok: true, catalog, webhookUrl, cachedAt: cached.tbx_catalog_ts || 0 };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg?.type === 'GET_CATALOG' || msg?.type === 'REFRESH_CATALOG') {
        const data = await fetchLiveCatalog(msg.type === 'REFRESH_CATALOG');
        sendResponse(data);
        return;
      }

      if (msg?.type === 'SCAN_3D_LINK') {
        const cfg = await fetchLiveCatalog(false);
        const webhookUrl = cfg.webhookUrl || DEFAULT_WEBHOOK_URL;
        const setup = cfg.catalog?.print3dSetup || FALLBACK_CATALOG.print3dSetup;
        const mats = cfg.catalog?.print3dMaterials || FALLBACK_CATALOG.print3dMaterials;
        const matchedMat = mats.find((m) => m.name.toLowerCase() === String(msg.material || 'PLA').toLowerCase()) || mats[0];

        const res = await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify({
            type: 'scan_drive_stl',
            fileUrl: String(msg.fileUrl || '').trim(),
            material: msg.material || 'PLA',
            quantity: Number(msg.quantity || 1),
            unitPricePerGram: Number(matchedMat.pricePerGram || 800),
            baseFee: Number(matchedMat.baseFee || 0),
            printerModel: setup.printerModel,
            nozzleMm: setup.nozzleMm,
            layerHeightMm: setup.layerHeightMm,
            wallLoops: setup.wallLoops,
            topBottomLayers: setup.topBottomLayers,
            infillPercent: Number(String(msg.infill || '20').replace(/\D/g, '')) || 20,
            uiInfillPercent: Number(String(msg.infill || '20').replace(/\D/g, '')) || 20,
            supportEnabled: true,
            ignoreReferenceFiles: true,
          }),
        });
        const json = await res.json();
        sendResponse(json);
        return;
      }

      if (msg?.type === 'CREATE_PRODUCT_ORDER') {
        const cfg = await fetchLiveCatalog(false);
        const webhookUrl = cfg.webhookUrl || DEFAULT_WEBHOOK_URL;
        const profile = cfg.catalog?.profile || FALLBACK_CATALOG.profile;
        const payload = {
          event: 'new_order',
          notifyTelegram: true,
          buyerEmailEnabled: Boolean(msg.order?.customerEmail),
          shop: profile.name || 'TeeBi & Robot',
          shopPhone: profile.phone || '0789044703',
          order: msg.order,
        };
        const res = await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(payload),
        });
        const json = await res.json();
        sendResponse(json);
        return;
      }

      sendResponse({ ok: false, error: 'Unknown message type' });
    } catch (err) {
      sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) });
    }
  })();
  return true;
});
