var TBXStlScan = function(exports) {
  "use strict";
  const PETG_WEIGHT_DENSITY_G_CM3 = 1.27;
  const PETG_SUPPORT_MULTIPLIER = 1.3;
  const PETG_HIDDEN_WEIGHT_MULTIPLIER = 1.2;
  function getInfillWeightMultiplier(uiInfillPercent) {
    const n = Number(uiInfillPercent);
    const clamped = Number.isFinite(n) ? Math.min(100, Math.max(20, n)) : 20;
    return 1 + (clamped - 20) / 80 * 1.5;
  }
  function roundWeightGrams(grams) {
    const w = Math.max(0, Number(grams) || 0);
    if (w === 0) return 0;
    return Number(w.toFixed(w < 10 ? 2 : 1));
  }
  function getSupportMultiplier(_material) {
    return PETG_SUPPORT_MULTIPLIER;
  }
  function getHiddenWeightMultiplier(_material) {
    return PETG_HIDDEN_WEIGHT_MULTIPLIER;
  }
  function getMaterialDensity(_material) {
    return PETG_WEIGHT_DENSITY_G_CM3;
  }
  function formatPrintDuration(totalMinutes) {
    const mins = Math.max(1, Math.round(totalMinutes));
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  }
  function parseStlGeometry(buffer) {
    const len = buffer.byteLength;
    if (len < 84) {
      throw new Error("Không đọc được hình học STL (chỉ hỗ trợ trực tiếp .STL Binary/ASCII).");
    }
    const u8All = new Uint8Array(buffer);
    let textEncoding = "utf-8";
    if (u8All[0] === 255 && u8All[1] === 254) {
      textEncoding = "utf-16le";
    } else if (u8All[0] === 254 && u8All[1] === 255) {
      textEncoding = "utf-16be";
    }
    const headSlice = new Uint8Array(buffer, 0, Math.min(1024, len));
    const headUtf8 = new TextDecoder("utf-8").decode(headSlice);
    const headText = textEncoding === "utf-8" ? headUtf8 : new TextDecoder(textEncoding).decode(headSlice);
    if (/^\s*(?:<!doctype\s+html|<html\b)/i.test(headUtf8) || /^\s*(?:<!doctype\s+html|<html\b)/i.test(headText)) {
      throw new Error("Không đọc được hình học STL (chỉ hỗ trợ trực tiếp .STL Binary/ASCII).");
    }
    const dv = new DataView(buffer);
    const possibleCount = dv.getUint32(80, true);
    const expectedBinarySize = 84 + possibleCount * 50;
    const looksAsciiStl = /facet\s+normal/i.test(headText) && /outer\s+loop/i.test(headText);
    const tryParseBinary = (count) => {
      if (count <= 0) return null;
      let vol6 = 0;
      let area2 = 0;
      let minX = Infinity;
      let minY = Infinity;
      let minZ = Infinity;
      let maxX = -Infinity;
      let maxY = -Infinity;
      let maxZ = -Infinity;
      let validTriangles = 0;
      for (let i = 0; i < count; i++) {
        const off = 84 + i * 50;
        if (off + 48 > len) break;
        const ax = dv.getFloat32(off + 12, true);
        const ay = dv.getFloat32(off + 16, true);
        const az = dv.getFloat32(off + 20, true);
        const bx = dv.getFloat32(off + 24, true);
        const by = dv.getFloat32(off + 28, true);
        const bz = dv.getFloat32(off + 32, true);
        const cx = dv.getFloat32(off + 36, true);
        const cy = dv.getFloat32(off + 40, true);
        const cz = dv.getFloat32(off + 44, true);
        if (!Number.isFinite(ax) || !Number.isFinite(ay) || !Number.isFinite(az) || !Number.isFinite(bx) || !Number.isFinite(by) || !Number.isFinite(bz) || !Number.isFinite(cx) || !Number.isFinite(cy) || !Number.isFinite(cz)) {
          continue;
        }
        if (ax < minX) minX = ax;
        if (bx < minX) minX = bx;
        if (cx < minX) minX = cx;
        if (ay < minY) minY = ay;
        if (by < minY) minY = by;
        if (cy < minY) minY = cy;
        if (az < minZ) minZ = az;
        if (bz < minZ) minZ = bz;
        if (cz < minZ) minZ = cz;
        if (ax > maxX) maxX = ax;
        if (bx > maxX) maxX = bx;
        if (cx > maxX) maxX = cx;
        if (ay > maxY) maxY = ay;
        if (by > maxY) maxY = by;
        if (cy > maxY) maxY = cy;
        if (az > maxZ) maxZ = az;
        if (bz > maxZ) maxZ = bz;
        if (cz > maxZ) maxZ = cz;
        vol6 += -cx * by * az + bx * cy * az + cx * ay * bz - ax * cy * bz - bx * ay * cz + ax * by * cz;
        const ux = bx - ax;
        const uy = by - ay;
        const uz = bz - az;
        const vx = cx - ax;
        const vy = cy - ay;
        const vz = cz - az;
        const nx = uy * vz - uz * vy;
        const ny = uz * vx - ux * vz;
        const nz = ux * vy - uy * vx;
        area2 += Math.sqrt(nx * nx + ny * ny + nz * nz);
        validTriangles += 1;
      }
      if (validTriangles === 0 || !Number.isFinite(minX) || Math.max(
        Math.abs(minX),
        Math.abs(maxX),
        Math.abs(minY),
        Math.abs(maxY),
        Math.abs(minZ),
        Math.abs(maxZ)
      ) >= 1e7) {
        return null;
      }
      return {
        triangles: validTriangles,
        sizeX: Number((maxX - minX).toFixed(1)),
        sizeY: Number((maxY - minY).toFixed(1)),
        sizeZ: Number((maxZ - minZ).toFixed(1)),
        volumeCm3: Number((Math.abs(vol6) / 6 / 1e3).toFixed(2)),
        surfaceAreaCm2: Number((area2 / 2 / 100).toFixed(2))
      };
    };
    const tryParseAscii = () => {
      let vol6 = 0;
      let area2 = 0;
      let minX = Infinity;
      let minY = Infinity;
      let minZ = Infinity;
      let maxX = -Infinity;
      let maxY = -Infinity;
      let maxZ = -Infinity;
      let validTriangles = 0;
      const text = new TextDecoder(textEncoding).decode(u8All);
      const vertexRe = /vertex\s+([-+]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][-+]?\d+)?)\s+([-+]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][-+]?\d+)?)\s+([-+]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][-+]?\d+)?)/gi;
      const coords = [];
      let m;
      while ((m = vertexRe.exec(text)) !== null) {
        coords.push(
          Number(m[1].replace(",", ".")),
          Number(m[2].replace(",", ".")),
          Number(m[3].replace(",", "."))
        );
        if (coords.length === 9) {
          const ax = coords[0];
          const ay = coords[1];
          const az = coords[2];
          const bx = coords[3];
          const by = coords[4];
          const bz = coords[5];
          const cx = coords[6];
          const cy = coords[7];
          const cz = coords[8];
          coords.length = 0;
          if (!Number.isFinite(ax) || !Number.isFinite(ay) || !Number.isFinite(az) || !Number.isFinite(bx) || !Number.isFinite(by) || !Number.isFinite(bz) || !Number.isFinite(cx) || !Number.isFinite(cy) || !Number.isFinite(cz)) {
            continue;
          }
          if (ax < minX) minX = ax;
          if (bx < minX) minX = bx;
          if (cx < minX) minX = cx;
          if (ay < minY) minY = ay;
          if (by < minY) minY = by;
          if (cy < minY) minY = cy;
          if (az < minZ) minZ = az;
          if (bz < minZ) minZ = bz;
          if (cz < minZ) minZ = cz;
          if (ax > maxX) maxX = ax;
          if (bx > maxX) maxX = bx;
          if (cx > maxX) maxX = cx;
          if (ay > maxY) maxY = ay;
          if (by > maxY) maxY = by;
          if (cy > maxY) maxY = cy;
          if (az > maxZ) maxZ = az;
          if (bz > maxZ) maxZ = bz;
          if (cz > maxZ) maxZ = cz;
          vol6 += -cx * by * az + bx * cy * az + cx * ay * bz - ax * cy * bz - bx * ay * cz + ax * by * cz;
          const ux = bx - ax;
          const uy = by - ay;
          const uz = bz - az;
          const vx = cx - ax;
          const vy = cy - ay;
          const vz = cz - az;
          const nx = uy * vz - uz * vy;
          const ny = uz * vx - ux * vz;
          const nz = ux * vy - uy * vx;
          area2 += Math.sqrt(nx * nx + ny * ny + nz * nz);
          validTriangles += 1;
        }
      }
      if (validTriangles === 0 || !Number.isFinite(minX)) {
        return null;
      }
      return {
        triangles: validTriangles,
        sizeX: Number((maxX - minX).toFixed(1)),
        sizeY: Number((maxY - minY).toFixed(1)),
        sizeZ: Number((maxZ - minZ).toFixed(1)),
        volumeCm3: Number((Math.abs(vol6) / 6 / 1e3).toFixed(2)),
        surfaceAreaCm2: Number((area2 / 2 / 100).toFixed(2))
      };
    };
    if (!looksAsciiStl && possibleCount > 0 && expectedBinarySize >= 134 && expectedBinarySize <= len + 4) {
      const binRes = tryParseBinary(possibleCount);
      if (binRes) return binRes;
    }
    const asciiRes = tryParseAscii();
    if (asciiRes) return asciiRes;
    if (!looksAsciiStl && len >= 134 && (len - 84) % 50 === 0) {
      const fallbackBin = tryParseBinary((len - 84) / 50);
      if (fallbackBin) return fallbackBin;
    }
    throw new Error("Không đọc được hình học STL (chỉ hỗ trợ trực tiếp .STL Binary/ASCII).");
  }
  function estimatePrintFromGeometry(geom, setup) {
    const { triangles, sizeX, sizeY, sizeZ, volumeCm3, surfaceAreaCm2 } = geom;
    const shellThicknessCm = setup.wallLoops * setup.nozzleMm / 10;
    const shellVol = Math.min(volumeCm3 * 0.65, surfaceAreaCm2 * shellThicknessCm * 0.85);
    const innerVol = Math.max(0, volumeCm3 - shellVol);
    const baseEffectiveVol = shellVol + innerVol * 0.7;
    const infillFactor = getInfillWeightMultiplier(setup.infillPercent);
    const supportFactor = getSupportMultiplier();
    const hiddenMaterialFactor = getHiddenWeightMultiplier();
    const density = getMaterialDensity();
    const estimatedWeightGrams = roundWeightGrams(
      Math.max(0.5, baseEffectiveVol * infillFactor * supportFactor * hiddenMaterialFactor * density)
    );
    const speedGramsPerMin = 0.24 * (setup.layerHeightMm / 0.2);
    const estimatedMinutes = Math.max(5, estimatedWeightGrams / Math.max(0.08, speedGramsPerMin));
    const maxX = setup.maxBuildX || 800;
    const maxY = setup.maxBuildY || 800;
    const maxZ = setup.maxBuildZ || 800;
    const exceedsBuildVolume = sizeX > maxX || sizeY > maxY || sizeZ > maxZ;
    const maxBuildLabel = `${maxX} × ${maxY} × ${maxZ} mm`;
    return {
      triangles,
      sizeX,
      sizeY,
      sizeZ,
      volumeCm3,
      surfaceAreaCm2,
      estimatedWeightGrams,
      estimatedPrintTime: formatPrintDuration(estimatedMinutes),
      exceedsBuildVolume,
      maxBuildLabel
    };
  }
  function analyzeStlAndEstimatePrint(buffer, setup) {
    return estimatePrintFromGeometry(parseStlGeometry(buffer), setup);
  }
  const EOCD_SIG = 101010256;
  const CEN_SIG = 33639248;
  const LOC_SIG = 67324752;
  function isIgnoredArchiveEntry(rawPath) {
    const normalized = rawPath.replace(/\\/g, "/").trim();
    if (!normalized || normalized.endsWith("/")) return true;
    const lower = normalized.toLowerCase();
    if (lower.startsWith("__macosx/") || lower.includes("/__macosx/")) return true;
    const base = lower.split("/").pop() || "";
    if (!base) return true;
    return base === ".ds_store" || base.startsWith("._") || base === "thumbs.db" || base === "desktop.ini";
  }
  async function decompressDeflateRaw(compressed, expectedSize) {
    if (typeof DecompressionStream === "undefined") {
      throw new Error("Browser does not support DecompressionStream");
    }
    const copy = new Uint8Array(compressed.byteLength);
    copy.set(compressed);
    const reader = new Blob([copy]).stream().pipeThrough(new DecompressionStream("deflate-raw")).getReader();
    const output = new Uint8Array(expectedSize);
    let offset = 0;
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        if (offset + value.byteLength > expectedSize) throw new Error("ZIP entry exceeds declared size");
        output.set(value, offset);
        offset += value.byteLength;
      }
      if (offset !== expectedSize) throw new Error("ZIP entry does not match declared size");
      return output.buffer;
    } finally {
      await reader.cancel().catch(() => {
      });
      reader.releaseLock();
    }
  }
  async function extractStlFilesFromZipBuffer(buffer, maxSingleFileBytes, maxFiles = 20, options = {}) {
    var _a;
    const len = buffer.byteLength;
    if (len < 22) {
      throw new Error("ZIP file too small");
    }
    const dv = new DataView(buffer);
    const minOffset = Math.max(0, len - 65557);
    let eocdOffset = -1;
    for (let i = len - 22; i >= minOffset; i--) {
      if (dv.getUint32(i, true) === EOCD_SIG) {
        eocdOffset = i;
        break;
      }
    }
    if (eocdOffset < 0) {
      throw new Error("EOCD signature not found");
    }
    const totalEntries = dv.getUint16(eocdOffset + 10, true);
    const cdSize = dv.getUint32(eocdOffset + 12, true);
    const cdOffset = dv.getUint32(eocdOffset + 16, true);
    if (totalEntries === 65535 || cdOffset === 4294967295 || cdOffset + cdSize > len) {
      throw new Error("ZIP64 or out-of-bounds Central Directory");
    }
    const utf8Decoder = new TextDecoder("utf-8");
    const out = [];
    let extractedBytes = 0;
    let cursor = cdOffset;
    for (let idx = 0; idx < totalEntries; idx++) {
      if (cursor + 46 > len || dv.getUint32(cursor, true) !== CEN_SIG) {
        throw new Error("Invalid Central Directory entry");
      }
      const flags = dv.getUint16(cursor + 8, true);
      const compressionMethod = dv.getUint16(cursor + 10, true);
      const compressedSize = dv.getUint32(cursor + 20, true);
      const uncompressedSize = dv.getUint32(cursor + 24, true);
      const nameLen = dv.getUint16(cursor + 28, true);
      const extraLen = dv.getUint16(cursor + 30, true);
      const commentLen = dv.getUint16(cursor + 32, true);
      const localHeaderOffset = dv.getUint32(cursor + 42, true);
      if (cursor + 46 + nameLen > len) {
        throw new Error("Corrupt ZIP filename length");
      }
      const rawName = utf8Decoder.decode(new Uint8Array(buffer, cursor + 46, nameLen));
      cursor += 46 + nameLen + extraLen + commentLen;
      if (isIgnoredArchiveEntry(rawName)) {
        continue;
      }
      const baseName = ((_a = rawName.replace(/\\/g, "/").split("/").pop()) == null ? void 0 : _a.trim()) || "";
      if (!baseName.toLowerCase().endsWith(".stl")) {
        if (options.skipNonStl) continue;
        throw new Error(`Unsupported file inside ZIP: ${baseName}`);
      }
      if ((flags & 1) !== 0) throw new Error("Encrypted ZIP entry is not supported");
      if (uncompressedSize > maxSingleFileBytes) {
        throw new Error(`STL inside ZIP exceeds limit: ${baseName}`);
      }
      if (out.length >= maxFiles) {
        throw new Error("Too many STL files inside ZIP");
      }
      if (options.maxTotalBytes !== void 0 && extractedBytes + uncompressedSize > options.maxTotalBytes) {
        throw new Error("Total extracted STL size exceeds limit");
      }
      if (localHeaderOffset + 30 > len || dv.getUint32(localHeaderOffset, true) !== LOC_SIG) {
        throw new Error("Invalid local file header inside ZIP");
      }
      const localNameLen = dv.getUint16(localHeaderOffset + 26, true);
      const localExtraLen = dv.getUint16(localHeaderOffset + 28, true);
      const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
      if (dataStart + compressedSize > len) {
        throw new Error("Compressed entry out of bounds");
      }
      const compressedSlice = new Uint8Array(buffer, dataStart, compressedSize);
      let outBuf;
      if (compressionMethod === 0) {
        outBuf = compressedSlice.slice().buffer;
      } else if (compressionMethod === 8) {
        outBuf = await decompressDeflateRaw(compressedSlice, uncompressedSize);
      } else {
        throw new Error(`Unsupported ZIP compression method: ${compressionMethod}`);
      }
      if (outBuf.byteLength < 84 || outBuf.byteLength > maxSingleFileBytes || outBuf.byteLength !== uncompressedSize) {
        throw new Error(`Invalid extracted STL size: ${baseName}`);
      }
      out.push({ name: baseName, buffer: outBuf });
      extractedBytes += outBuf.byteLength;
    }
    if (out.length === 0) {
      throw new Error("No STL files found in ZIP");
    }
    return out;
  }
  const MIB = 1024 * 1024;
  const MAX_FILE_BYTES = 60 * MIB;
  const MAX_TOTAL_STL_BYTES = 120 * MIB;
  const MAX_MODELS = 20;
  async function scanFiles(files, settings, quantity) {
    const setup = {
      printerModel: "Creality",
      nozzleMm: 0.4,
      layerHeightMm: 0.2,
      wallLoops: 3,
      topBottomLayers: 4,
      infillPercent: 20,
      supportEnabled: true,
      material: "PLA",
      ...settings
    };
    const models = [];
    let stlBytes = 0;
    for (const file of files) {
      if (!/\.(stl|zip)$/i.test(file.name)) throw new Error(`Chọn file STL hoặc ZIP (${file.name}).`);
      if (file.size > MAX_FILE_BYTES) throw new Error(`${file.name} vượt giới hạn 60 MB.`);
      const buffer = await file.arrayBuffer();
      let entries;
      try {
        entries = /\.zip$/i.test(file.name) ? await extractStlFilesFromZipBuffer(buffer, MAX_FILE_BYTES, MAX_MODELS - models.length, {
          skipNonStl: true,
          maxTotalBytes: MAX_TOTAL_STL_BYTES - stlBytes
        }) : [{ name: file.name, buffer }];
      } catch (error) {
        const reason = error instanceof Error ? error.message : "";
        if (reason === "No STL files found in ZIP") throw new Error(`${file.name} không có file STL.`);
        if (/exceeds limit|Too many STL/.test(reason)) throw new Error("Chọn tối đa 20 mẫu STL, tổng dung lượng 120 MB.");
        throw new Error(`Không đọc được ZIP ${file.name}. Hãy giải nén và chọn các file STL.`);
      }
      for (const entry of entries) {
        stlBytes += entry.buffer.byteLength;
        if (models.length >= MAX_MODELS || stlBytes > MAX_TOTAL_STL_BYTES) {
          throw new Error("Chọn tối đa 20 mẫu STL, tổng dung lượng 120 MB.");
        }
        try {
          const result = analyzeStlAndEstimatePrint(entry.buffer, setup);
          if (!Number.isFinite(result.estimatedWeightGrams) || result.estimatedWeightGrams <= 0) throw new Error();
          models.push({
            fileName: entry.name,
            dimensions: `${result.sizeX} x ${result.sizeY} x ${result.sizeZ} mm`,
            perPartWeightGrams: result.estimatedWeightGrams
          });
        } catch {
          throw new Error(`Không đọc được hình học trong ${entry.name}. Hãy xuất lại mẫu dưới dạng STL.`);
        }
      }
    }
    if (!models.length) throw new Error("Chọn ít nhất một file STL.");
    const weightPerSet = models.reduce((total, model) => total + model.perPartWeightGrams, 0);
    return {
      ok: true,
      fileName: models.length === 1 ? models[0].fileName : `${models.length} mẫu STL`,
      source: "local-stl",
      perPartWeightGrams: roundWeightGrams(weightPerSet),
      totalWeightGrams: roundWeightGrams(weightPerSet * quantity),
      dimensions: models.map((model) => model.dimensions).join(" | "),
      printTime: formatPrintDuration(weightPerSet / Math.max(0.08, 0.24 * (setup.layerHeightMm / 0.2))),
      files: models
    };
  }
  exports.scanFiles = scanFiles;
  Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
  return exports;
}({});
